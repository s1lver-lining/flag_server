#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>
#include <termios.h>
#include <unistd.h>

// Flag Validator Machine (FVM) Debugger

#define MAX_MEMORY 65535
#define MAX_STACK 64
#define FLAG_MAX_LEN 64
#define MAX_BREAKPOINTS 16
#define MAX_HISTORY 100
#define MAX_CMD_LEN 256

// Instruction opcodes
typedef enum {
    OP_NOP = 0x00,
    OP_MOV = 0x01,
    OP_LOAD = 0x02,
    OP_STORE = 0x03,
    OP_ADD = 0x04,
    OP_SUB = 0x05,
    OP_XOR = 0x06,
    OP_CMP = 0x07,
    OP_JMP = 0x08,
    OP_JZ = 0x09,
    OP_JNZ = 0x0A,
    OP_PUSH = 0x0B,
    OP_POP = 0x0C,
    OP_PRINT = 0x0D,
    OP_GETC = 0x0E,
    OP_GETCX = 0x0F,
    OP_ZZZR = 0x10,
    OP_ZZZ = 0x11,
    OP_RNG  = 0x12,
    OP_BONK = 0x13,
    OP_ADDR = 0x14,
    OP_SUBR = 0x15,
    OP_XORR = 0x16,
    OP_CMPR = 0x17,
    OP_WIPE = 0x18,
    OP_HALT = 0xFF
} Opcode;

// VM State
typedef struct {
    uint8_t regs[8];
    uint8_t memory[MAX_MEMORY];
    uint8_t stack[MAX_STACK];
    uint8_t sp;
    uint16_t pc;
    uint8_t zero_flag;
    uint8_t halt;
    char input[FLAG_MAX_LEN];
    int input_len;
    uint8_t breakpoints[MAX_BREAKPOINTS];
    int num_breakpoints;
    int bytecode_size;
    char output_buffer[256];
    int output_len;
    uint32_t rng_state;         // Internal state for RNG instruction
} VMState;

// Color codes for GEF-like output
#define COLOR_RESET "\033[0m"
#define COLOR_BOLD "\033[1m"
#define COLOR_RED "\033[31m"
#define COLOR_GREEN "\033[32m"
#define COLOR_YELLOW "\033[33m"
#define COLOR_BLUE "\033[34m"
#define COLOR_MAGENTA "\033[35m"
#define COLOR_CYAN "\033[36m"
#define COLOR_GRAY "\033[90m"
#define COLOR_BOLD_RED "\033[1;31m"
#define COLOR_BOLD_GREEN "\033[1;32m"
#define COLOR_BOLD_YELLOW "\033[1;33m"
#define COLOR_BOLD_BLUE "\033[1;34m"
#define COLOR_BOLD_MAGENTA "\033[1;35m"
#define COLOR_BOLD_CYAN "\033[1;36m"

// Initialize VM
void vm_init(VMState *vm, const char *input) {
    memset(vm, 0, sizeof(VMState));
    strncpy(vm->input, input, FLAG_MAX_LEN - 1);
    vm->input_len = strlen(vm->input);
    vm->output_len = 0;
    vm->rng_state = 0xC0FEBABE;
}

// Load bytecode from text file
int load_bytecode(const char *filename, uint8_t *memory, size_t max_size) {
    FILE *f = fopen(filename, "r");
    if (!f) {
        fprintf(stderr, "Error: Cannot open bytecode file '%s'\n", filename);
        return -1;
    }
    
    char line[256];
    int code_idx = 0;
    int line_num = 0;
    
    while (fgets(line, sizeof(line), f) && code_idx < max_size) {
        line_num++;
        
        if (line[0] == '\n' || line[0] == '#' || line[0] == ';') {
            continue;
        }
        
        char *ptr = line;
        while (*ptr && code_idx < max_size) {
            while (*ptr == ' ' || *ptr == '\t' || *ptr == '\n' || *ptr == '\r') {
                ptr++;
            }
            
            if (*ptr == '\0' || *ptr == '#' || *ptr == ';') {
                break;
            }
            
            unsigned int byte;
            if (sscanf(ptr, "%2x", &byte) == 1) {
                memory[code_idx++] = (uint8_t)byte;
                ptr += 2;
            } else {
                fprintf(stderr, "Warning: Invalid hex on line %d\n", line_num);
                break;
            }
        }
    }
    
    fclose(f);
    
    if (code_idx == 0) {
        fprintf(stderr, "Error: No valid bytecode found\n");
        return -1;
    }
    
    return code_idx;
}

// Get opcode name
const char* get_opcode_name(uint8_t opcode) {
    switch (opcode) {
        case OP_NOP: return "NOP";
        case OP_MOV: return "MOV";
        case OP_LOAD: return "LOAD";
        case OP_STORE: return "STORE";
        case OP_ADD: return "ADD";
        case OP_SUB: return "SUB";
        case OP_XOR: return "XOR";
        case OP_CMP: return "CMP";
        case OP_JMP: return "JMP";
        case OP_JZ: return "JZ";
        case OP_JNZ: return "JNZ";
        case OP_PUSH: return "PUSH";
        case OP_POP: return "POP";
        case OP_PRINT: return "PRINT";
        case OP_GETC: return "GETC";
        case OP_GETCX: return "GETCX";
        case OP_ZZZR: return "ZZZR";
        case OP_ZZZ: return "ZZZ";
        case OP_RNG:  return "RNG";
        case OP_BONK: return "BONK";
        case OP_ADDR: return "ADDR";
        case OP_SUBR: return "SUBR";
        case OP_XORR: return "XORR";
        case OP_CMPR: return "CMPR";
        case OP_WIPE: return "WIPE";
        case OP_HALT: return "HALT";
        default: return "???";
    }
}

// Get instruction size
int get_instruction_size(uint8_t opcode) {
    switch (opcode) {
        case OP_NOP:
        case OP_HALT:
        case OP_WIPE:
        case OP_BONK:
            return 1;
        case OP_PUSH:
        case OP_POP:
        case OP_PRINT:
        case OP_ZZZR:
        case OP_RNG:
            return 2;
        case OP_JMP:
        case OP_JZ:
        case OP_JNZ:
        case OP_ZZZ:
            return 5;  // 4-byte address or 4-byte immediate
        case OP_LOAD:
        case OP_STORE:
            return 7;  // reg + 4-byte base address + reg_offset
        default:
            return 3;  // MOV, ADD, SUB, XOR, CMP, GETC, GETCX, ADDR, SUBR, XORR, CMPR
    }
}

// Disassemble instruction at given address
void disassemble_instruction(VMState *vm, uint16_t addr, int is_current) {
    if (addr >= vm->bytecode_size) {
        printf("  %s<out of bounds>%s\n", COLOR_RED, COLOR_RESET);
        return;
    }
    
    uint8_t opcode = vm->memory[addr];
    uint8_t arg1 = (addr + 1 < MAX_MEMORY) ? vm->memory[addr + 1] : 0;
    uint8_t arg2 = (addr + 2 < MAX_MEMORY) ? vm->memory[addr + 2] : 0;
    uint8_t arg3 = (addr + 3 < MAX_MEMORY) ? vm->memory[addr + 3] : 0;
    uint8_t arg4 = (addr + 4 < MAX_MEMORY) ? vm->memory[addr + 4] : 0;
    uint8_t arg5 = (addr + 5 < MAX_MEMORY) ? vm->memory[addr + 5] : 0;
    uint8_t arg6 = (addr + 6 < MAX_MEMORY) ? vm->memory[addr + 6] : 0;
    
    const char *arrow = is_current ? COLOR_BOLD_GREEN "=> " COLOR_RESET : "   ";
    const char *name_color = is_current ? COLOR_BOLD_CYAN : COLOR_CYAN;
    int instr_size = get_instruction_size(opcode);
    
    // Print address
    printf("%s%s0x%08x%s  ", arrow, COLOR_YELLOW, addr, COLOR_RESET);
    
    // Print hex bytes (with fixed width for alignment)
    printf("%s", COLOR_GRAY);
    switch (instr_size) {
        case 1:
            printf("%02x                ", opcode);
            break;
        case 2:
            printf("%02x %02x             ", opcode, arg1);
            break;
        case 3:
            printf("%02x %02x %02x          ", opcode, arg1, arg2);
            break;
        case 5:
            printf("%02x %02x%02x%02x%02x       ", opcode, arg1, arg2, arg3, arg4);
            break;
        case 6:
            printf("%02x %02x %02x%02x%02x%02x ", opcode, arg1, arg2, arg3, arg4, arg5);
            break;
        case 7:
            printf("%02x %02x%02x%02x%02x %02x %02x ", opcode, arg1, arg2, arg3, arg4, arg5, arg6);
            break;
    }
    printf("%s  ", COLOR_RESET);
    
    // Print disassembly
    switch (opcode) {
        case OP_NOP:
            printf("%s%-6s%s\n", name_color, get_opcode_name(opcode), COLOR_RESET);
            break;
        case OP_MOV:
            printf("%s%-6s%s r%d, 0x%02x", name_color, get_opcode_name(opcode), COLOR_RESET, arg1, arg2);
            if (isprint(arg2)) printf(" %s; '%c'%s", COLOR_GRAY, arg2, COLOR_RESET);
            printf("\n");
            break;
        case OP_LOAD: {
            uint32_t base_addr = (arg2 << 24) | (arg3 << 16) | (arg4 << 8) | arg5;
            uint8_t reg_offset = arg6;
            printf("%s%-6s%s r%d, [0x%08x + r%d]", name_color, get_opcode_name(opcode), COLOR_RESET, arg1, base_addr, reg_offset);
            if (reg_offset < 8) {
                printf(" %s; [0x%08x]%s", COLOR_GRAY, base_addr + vm->regs[reg_offset], COLOR_RESET);
            }
            printf("\n");
            break;
        }
        case OP_STORE: {
            uint32_t base_addr = (arg1 << 24) | (arg2 << 16) | (arg3 << 8) | arg4;
            uint8_t reg_offset = arg5;
            uint8_t reg_src = arg6;
            printf("%s%-6s%s [0x%08x + r%d], r%d", name_color, get_opcode_name(opcode), COLOR_RESET, base_addr, reg_offset, reg_src);
            if (reg_offset < 8) {
                printf(" %s; [0x%08x]%s", COLOR_GRAY, base_addr + vm->regs[reg_offset], COLOR_RESET);
            }
            printf("\n");
            break;
        }
        case OP_ADD:
        case OP_SUB:
        case OP_XOR:
            printf("%s%-6s%s r%d, 0x%02x\n", name_color, get_opcode_name(opcode), COLOR_RESET, arg1, arg2);
            break;
        case OP_CMP:
            printf("%s%-6s%s r%d, 0x%02x", name_color, get_opcode_name(opcode), COLOR_RESET, arg1, arg2);
            if (isprint(arg2)) printf(" %s; '%c'%s", COLOR_GRAY, arg2, COLOR_RESET);
            printf("\n");
            break;
        case OP_JMP:
        case OP_JZ:
        case OP_JNZ: {
            uint32_t jmp_addr = (arg1 << 24) | (arg2 << 16) | (arg3 << 8) | arg4;
            printf("%s%-6s%s 0x%08x\n", name_color, get_opcode_name(opcode), COLOR_RESET, jmp_addr);
            break;
        }
        case OP_PUSH:
        case OP_POP:
            printf("%s%-6s%s r%d\n", name_color, get_opcode_name(opcode), COLOR_RESET, arg1);
            break;
        case OP_PRINT:
            printf("%s%-6s%s r%d\n", name_color, get_opcode_name(opcode), COLOR_RESET, arg1);
            break;
        case OP_GETC:
            printf("%s%-6s%s r%d, %d", name_color, get_opcode_name(opcode), COLOR_RESET, arg1, arg2);
            if (arg2 < vm->input_len) {
                printf(" %s; input[%d]='%c'%s", COLOR_GRAY, arg2, vm->input[arg2], COLOR_RESET);
            }
            printf("\n");
            break;
        case OP_GETCX:
            printf("%s%-6s%s r%d, r%d", name_color, get_opcode_name(opcode), COLOR_RESET, arg1, arg2);
            if (arg2 < 8) {
                uint8_t idx = vm->regs[arg2];
                if (idx < vm->input_len) {
                    printf(" %s; r%d=%d, input[%d]='%c'%s", COLOR_GRAY, arg2, idx, idx, vm->input[idx], COLOR_RESET);
                } else {
                    printf(" %s; r%d=%d (out of bounds)%s", COLOR_GRAY, arg2, idx, COLOR_RESET);
                }
            }
            printf("\n");
            break;
        case OP_ZZZR:
            printf("%s%-6s%s r%d", name_color, get_opcode_name(opcode), COLOR_RESET, arg1);
            if (arg1 < 8) {
                printf(" %s; sleep %u seconds 💤%s", COLOR_GRAY, vm->regs[arg1], COLOR_RESET);
            }
            printf("\n");
            break;
        case OP_ZZZ: {
            uint32_t sleep_seconds = (arg1 << 24) | (arg2 << 16) | (arg3 << 8) | arg4;
            printf("%s%-6s%s %u", name_color, get_opcode_name(opcode), COLOR_RESET, sleep_seconds);
            printf(" %s; sleep %u seconds 💤💤💤%s\n", COLOR_GRAY, sleep_seconds, COLOR_RESET);
            break;
        }
        case OP_RNG:
            printf("%s%-6s%s r%d", name_color, get_opcode_name(opcode), COLOR_RESET, arg1);
            printf(" %s; 🎲 r%d = pseudo_rng(pc=0x%04x, state=0x%08x)%s\n",
                   COLOR_GRAY, arg1, addr, vm->rng_state, COLOR_RESET);
            break;
        case OP_BONK:
            printf("%s%-6s%s", name_color, get_opcode_name(opcode), COLOR_RESET);
            printf(" %s; 🔄 rotate: r0=0x%02x r1=0x%02x r2=0x%02x r3=0x%02x r4=0x%02x r5=0x%02x r6=0x%02x r7=0x%02x → r0←r7%s\n",
                   COLOR_GRAY,
                   vm->regs[0], vm->regs[1], vm->regs[2], vm->regs[3],
                   vm->regs[4], vm->regs[5], vm->regs[6], vm->regs[7],
                   COLOR_RESET);
            break;
        case OP_WIPE:
            printf("%s%-6s%s", name_color, get_opcode_name(opcode), COLOR_RESET);
            printf(" %s; 🧹 all registers → 0x00%s\n", COLOR_GRAY, COLOR_RESET);
            break;
        case OP_ADDR:
        case OP_SUBR:
        case OP_XORR:
        case OP_CMPR:
            printf("%s%-6s%s r%d, r%d", name_color, get_opcode_name(opcode), COLOR_RESET, arg1, arg2);
            if (arg1 < 8 && arg2 < 8) {
                printf(" %s; r%d=0x%02x, r%d=0x%02x%s", COLOR_GRAY, arg1, vm->regs[arg1], arg2, vm->regs[arg2], COLOR_RESET);
            }
            printf("\n");
            break;
        case OP_HALT:
            printf("%s%-6s%s\n", name_color, get_opcode_name(opcode), COLOR_RESET);
            break;
        default:
            printf("%s%-6s%s 0x%02x 0x%02x\n", COLOR_RED, "???", COLOR_RESET, arg1, arg2);
            break;
    }
}

// Display registers (GEF-style)
void display_registers(VMState *vm) {
    printf("%s────────────────────────────────[ REGISTERS ]───────────────────────────────────%s\n", 
           COLOR_BOLD_BLUE, COLOR_RESET);
    
    for (int i = 0; i < 8; i++) {
        if (i % 4 == 0 && i > 0) printf("\n");
        
        const char *reg_color = (vm->regs[i] == 0) ? COLOR_GRAY : COLOR_BOLD_GREEN;
        printf("%sr%d%s: 0x%02x %s%-3d%s ", 
               COLOR_CYAN, i, COLOR_RESET,
               vm->regs[i], reg_color, vm->regs[i], COLOR_RESET);
        
        if (isprint(vm->regs[i])) {
            printf("%s'%c'%s   ", COLOR_YELLOW, vm->regs[i], COLOR_RESET);
        } else {
            printf("      ");
        }
    }
    printf("\n");
    
    // Flags
    printf("\n%sFlags:%s ZF=%s%d%s  ", 
           COLOR_BOLD, COLOR_RESET,
           vm->zero_flag ? COLOR_BOLD_GREEN : COLOR_GRAY,
           vm->zero_flag, COLOR_RESET);
    
    printf("%sPC:%s %s0x%08x%s (%d)  %sSP:%s %s0x%02x%s (%d)\n",
           COLOR_BOLD, COLOR_RESET, COLOR_YELLOW, vm->pc, COLOR_RESET, vm->pc,
           COLOR_BOLD, COLOR_RESET, COLOR_YELLOW, vm->sp, COLOR_RESET, vm->sp);
}

// Display stack
void display_stack(VMState *vm) {
    printf("%s──────────────────────────────────[ STACK ]─────────────────────────────────────%s\n",
           COLOR_BOLD_MAGENTA, COLOR_RESET);
    
    if (vm->sp == 0) {
        printf("  %s<empty>%s\n", COLOR_GRAY, COLOR_RESET);
    } else {
        int start = (vm->sp > 8) ? vm->sp - 8 : 0;
        for (int i = vm->sp - 1; i >= start; i--) {
            const char *marker = (i == vm->sp - 1) ? COLOR_BOLD_GREEN "→ " COLOR_RESET : "  ";
            printf("%s[%02d] 0x%02x %s%-3d%s", 
                   marker, i, vm->stack[i],
                   COLOR_GREEN, vm->stack[i], COLOR_RESET);
            if (isprint(vm->stack[i])) {
                printf("  %s'%c'%s", COLOR_YELLOW, vm->stack[i], COLOR_RESET);
            }
            printf("\n");
        }
        if (start > 0) {
            printf("  %s... (%d more)%s\n", COLOR_GRAY, start, COLOR_RESET);
        }
    }
}

// Display next instructions
void display_code(VMState *vm, int num_instructions) {
    printf("%s──────────────────────────────────[ CODE ]──────────────────────────────────────%s\n",
           COLOR_BOLD_CYAN, COLOR_RESET);
    
    uint16_t addr = vm->pc;
    for (int i = 0; i < num_instructions && addr < vm->bytecode_size; i++) {
        // Check for breakpoint
        int has_breakpoint = 0;
        for (int j = 0; j < vm->num_breakpoints; j++) {
            if (vm->breakpoints[j] == addr) {
                has_breakpoint = 1;
                break;
            }
        }
        
        if (has_breakpoint) {
            printf("%s●%s ", COLOR_BOLD_RED, COLOR_RESET);
        } else {
            printf("  ");
        }
        
        disassemble_instruction(vm, addr, (i == 0));
        
        uint8_t opcode = vm->memory[addr];
        addr += get_instruction_size(opcode);
    }
}

// Display output buffer
void display_output(VMState *vm) {
    if (vm->output_len > 0) {
        printf("%s──────────────────────────────────[ OUTPUT ]─────────────────────────────────────%s\n",
               COLOR_BOLD_YELLOW, COLOR_RESET);
        printf("  ");
        for (int i = 0; i < vm->output_len; i++) {
            printf("%c", vm->output_buffer[i]);
        }
        printf("\n");
    }
}

// Display input
void display_input(VMState *vm) {
    printf("%s──────────────────────────────────[ INPUT ]─────────────────────────────────────%s\n",
           COLOR_BOLD_GREEN, COLOR_RESET);
    printf("  \"%s%s%s\" (length: %d)\n", COLOR_YELLOW, vm->input, COLOR_RESET, vm->input_len);
    printf("  Hex: ");
    for (int i = 0; i < vm->input_len; i++) {
        printf("%02x ", (unsigned char)vm->input[i]);
    }
    printf("\n");
}

// Display full context
void display_context(VMState *vm) {
    printf("\n");
    display_registers(vm);
    printf("\n");
    display_code(vm, 8);
    printf("\n");
    display_stack(vm);
    printf("\n");
    display_output(vm);
    printf("\n");
    display_input(vm);
    printf("%s────────────────────────────────────────────────────────────────────────────────%s\n",
           COLOR_BOLD_BLUE, COLOR_RESET);
}

// Execute one instruction
int vm_step(VMState *vm) {
    if (vm->halt) {
        return 0;
    }
    
    if (vm->pc >= MAX_MEMORY || vm->pc >= vm->bytecode_size) {
        fprintf(stderr, "%sError: PC out of bounds%s\n", COLOR_BOLD_RED, COLOR_RESET);
        vm->halt = 1;
        return 0;
    }
    
    uint8_t opcode = vm->memory[vm->pc];
    uint8_t arg1 = vm->memory[vm->pc + 1];
    uint8_t arg2 = vm->memory[vm->pc + 2];
    uint8_t arg3 = vm->memory[vm->pc + 3];
    uint8_t arg4 = vm->memory[vm->pc + 4];
    
    switch (opcode) {
        case OP_NOP:
            vm->pc += 1;
            break;
            
        case OP_MOV:
            if (arg1 < 8) {
                vm->regs[arg1] = arg2;
            }
            vm->pc += 3;
            break;
            
        case OP_LOAD: {
            uint32_t base_addr = (arg2 << 24) | (arg3 << 16) | (arg4 << 8) | vm->memory[vm->pc + 5];
            uint8_t reg_offset = vm->memory[vm->pc + 6];
            if (arg1 < 8 && reg_offset < 8) {
                uint32_t addr = base_addr + vm->regs[reg_offset];
                if (addr < MAX_MEMORY) {
                    vm->regs[arg1] = vm->memory[addr];
                }
            }
            vm->pc += 7;
            break;
        }
            
        case OP_STORE: {
            uint32_t base_addr = (arg1 << 24) | (arg2 << 16) | (arg3 << 8) | arg4;
            uint8_t reg_offset = vm->memory[vm->pc + 5];
            uint8_t reg_src = vm->memory[vm->pc + 6];
            if (reg_offset < 8 && reg_src < 8) {
                uint32_t addr = base_addr + vm->regs[reg_offset];
                if (addr < MAX_MEMORY) {
                    vm->memory[addr] = vm->regs[reg_src];
                }
            }
            vm->pc += 7;
            break;
        }
            
        case OP_ADD:
            if (arg1 < 8) {
                vm->regs[arg1] += arg2;
            }
            vm->pc += 3;
            break;
            
        case OP_SUB:
            if (arg1 < 8) {
                vm->regs[arg1] -= arg2;
            }
            vm->pc += 3;
            break;
            
        case OP_XOR:
            if (arg1 < 8) {
                vm->regs[arg1] ^= arg2;
            }
            vm->pc += 3;
            break;
            
        case OP_CMP:
            if (arg1 < 8) {
                vm->zero_flag = (vm->regs[arg1] == arg2) ? 1 : 0;
            }
            vm->pc += 3;
            break;
            
        case OP_JMP: {
            uint32_t addr = (arg1 << 24) | (arg2 << 16) | (arg3 << 8) | arg4;
            vm->pc = addr;
            break;
        }
            
        case OP_JZ: {
            uint32_t addr = (arg1 << 24) | (arg2 << 16) | (arg3 << 8) | arg4;
            if (vm->zero_flag) {
                vm->pc = addr;
            } else {
                vm->pc += 5;
            }
            break;
        }
            
        case OP_JNZ: {
            uint32_t addr = (arg1 << 24) | (arg2 << 16) | (arg3 << 8) | arg4;
            if (!vm->zero_flag) {
                vm->pc = addr;
            } else {
                vm->pc += 5;
            }
            break;
        }
            
        case OP_PUSH:
            if (arg1 < 8 && vm->sp < MAX_STACK) {
                vm->stack[vm->sp++] = vm->regs[arg1];
            }
            vm->pc += 2;
            break;
            
        case OP_POP:
            if (arg1 < 8 && vm->sp > 0) {
                vm->regs[arg1] = vm->stack[--vm->sp];
            }
            vm->pc += 2;
            break;
            
        case OP_PRINT:
            if (arg1 < 8) {
                if (vm->output_len < sizeof(vm->output_buffer) - 1) {
                    vm->output_buffer[vm->output_len++] = vm->regs[arg1];
                    vm->output_buffer[vm->output_len] = '\0';
                }
            }
            vm->pc += 2;
            break;
            
        case OP_GETC:
            if (arg1 < 8) {
                if (arg2 < vm->input_len) {
                    vm->regs[arg1] = vm->input[arg2];
                } else {
                    vm->regs[arg1] = 0;
                }
            }
            vm->pc += 3;
            break;
            
        case OP_GETCX:
            if (arg1 < 8 && arg2 < 8) {
                uint8_t idx = vm->regs[arg2];
                if (idx < vm->input_len) {
                    vm->regs[arg1] = vm->input[idx];
                } else {
                    vm->regs[arg1] = 0;
                }
            }
            vm->pc += 3;
            break;
            
        case OP_ZZZR:
            if (arg1 < 8) {
                unsigned int sleep_seconds = vm->regs[arg1];
                printf("%sZZZR: Sleeping for %u seconds... 💤%s\n", COLOR_YELLOW, sleep_seconds, COLOR_RESET);
                sleep(sleep_seconds);
            }
            vm->pc += 2;
            break;
            
        case OP_ZZZ: {
            uint32_t sleep_seconds = (arg1 << 24) | (arg2 << 16) | (arg3 << 8) | arg4;
            printf("%sZZZ: Sleeping for %u seconds... 💤💤💤%s\n", COLOR_YELLOW, sleep_seconds, COLOR_RESET);
            sleep(sleep_seconds);
            vm->pc += 5;
            break;
        }
            
        case OP_ADDR:
            if (arg1 < 8 && arg2 < 8) {
                vm->regs[arg1] += vm->regs[arg2];
            }
            vm->pc += 3;
            break;
            
        case OP_SUBR:
            if (arg1 < 8 && arg2 < 8) {
                vm->regs[arg1] -= vm->regs[arg2];
            }
            vm->pc += 3;
            break;
            
        case OP_XORR:
            if (arg1 < 8 && arg2 < 8) {
                vm->regs[arg1] ^= vm->regs[arg2];
            }
            vm->pc += 3;
            break;
            
        case OP_CMPR:
            if (arg1 < 8 && arg2 < 8) {
                vm->zero_flag = (vm->regs[arg1] == vm->regs[arg2]) ? 1 : 0;
            }
            vm->pc += 3;
            break;

        case OP_RNG:
            if (arg1 < 8) {
                vm->rng_state ^= (uint32_t)vm->pc;
                vm->rng_state = vm->rng_state * 1664525u + 1013904223u;
                vm->regs[arg1] = (uint8_t)((vm->rng_state >> 16) & 0xFF);
            }
            vm->pc += 2;
            break;

        case OP_BONK: {
            uint8_t tmp = vm->regs[7];
            vm->regs[7] = vm->regs[6];
            vm->regs[6] = vm->regs[5];
            vm->regs[5] = vm->regs[4];
            vm->regs[4] = vm->regs[3];
            vm->regs[3] = vm->regs[2];
            vm->regs[2] = vm->regs[1];
            vm->regs[1] = vm->regs[0];
            vm->regs[0] = tmp;
            vm->pc += 1;
            break;
        }

        case OP_WIPE:
            memset(vm->regs, 0, sizeof(vm->regs));
            vm->pc += 1;
            break;
            
        case OP_HALT:
            vm->halt = 1;
            return 0;
            
        default:
            fprintf(stderr, "%sError: Unknown opcode 0x%02X at PC=%d%s\n", 
                    COLOR_BOLD_RED, opcode, vm->pc, COLOR_RESET);
            vm->halt = 1;
            return 0;
    }
    
    return 1;
}

// Check if at breakpoint
int at_breakpoint(VMState *vm) {
    for (int i = 0; i < vm->num_breakpoints; i++) {
        if (vm->breakpoints[i] == vm->pc) {
            return 1;
        }
    }
    return 0;
}

// Add breakpoint
void add_breakpoint(VMState *vm, uint8_t addr) {
    if (vm->num_breakpoints >= MAX_BREAKPOINTS) {
        printf("%sError: Maximum breakpoints reached%s\n", COLOR_BOLD_RED, COLOR_RESET);
        return;
    }
    
    // Check if already exists
    for (int i = 0; i < vm->num_breakpoints; i++) {
        if (vm->breakpoints[i] == addr) {
            printf("%sBreakpoint already exists at 0x%02x%s\n", COLOR_YELLOW, addr, COLOR_RESET);
            return;
        }
    }
    
    vm->breakpoints[vm->num_breakpoints++] = addr;
    printf("%sBreakpoint set at 0x%02x%s\n", COLOR_BOLD_GREEN, addr, COLOR_RESET);
}

// Remove breakpoint
void remove_breakpoint(VMState *vm, uint8_t addr) {
    for (int i = 0; i < vm->num_breakpoints; i++) {
        if (vm->breakpoints[i] == addr) {
            // Shift remaining breakpoints
            for (int j = i; j < vm->num_breakpoints - 1; j++) {
                vm->breakpoints[j] = vm->breakpoints[j + 1];
            }
            vm->num_breakpoints--;
            printf("%sBreakpoint removed at 0x%02x%s\n", COLOR_BOLD_GREEN, addr, COLOR_RESET);
            return;
        }
    }
    printf("%sNo breakpoint at 0x%02x%s\n", COLOR_YELLOW, addr, COLOR_RESET);
}

// List breakpoints
void list_breakpoints(VMState *vm) {
    if (vm->num_breakpoints == 0) {
        printf("%sNo breakpoints set%s\n", COLOR_GRAY, COLOR_RESET);
        return;
    }
    
    printf("%sBreakpoints:%s\n", COLOR_BOLD, COLOR_RESET);
    for (int i = 0; i < vm->num_breakpoints; i++) {
        printf("  %s%d%s: 0x%02x\n", COLOR_CYAN, i + 1, COLOR_RESET, vm->breakpoints[i]);
    }
}

// Examine memory
void examine_memory(VMState *vm, uint16_t addr, int count) {
    printf("%sMemory at 0x%04x:%s\n", COLOR_BOLD, addr, COLOR_RESET);
    
    for (int i = 0; i < count && addr + i < MAX_MEMORY; i += 16) {
        printf("%s0x%08x:%s ", COLOR_YELLOW, addr + i, COLOR_RESET);
        
        // Hex dump
        for (int j = 0; j < 16 && addr + i + j < MAX_MEMORY; j++) {
            printf("%02x ", vm->memory[addr + i + j]);
        }
        
        printf(" %s|%s ", COLOR_GRAY, COLOR_RESET);
        
        // ASCII dump
        for (int j = 0; j < 16 && addr + i + j < MAX_MEMORY; j++) {
            uint8_t byte = vm->memory[addr + i + j];
            if (isprint(byte)) {
                printf("%c", byte);
            } else {
                printf(".");
            }
        }
        printf("%s|%s\n", COLOR_GRAY, COLOR_RESET);
    }
}

// Print help
void print_help() {
    printf("\n%s═══════════════════════=═════ FVM DEBUGGER COMMANDS ════════════════════════════%s\n", 
           COLOR_BOLD_CYAN, COLOR_RESET);
    printf("%sExecution:%s\n", COLOR_BOLD, COLOR_RESET);
    printf("  %ss%s, %sstep%s         - Execute one instruction\n", COLOR_CYAN, COLOR_RESET, COLOR_CYAN, COLOR_RESET);
    printf("  %sr%s, %srun%s          - Run until halt or breakpoint\n", COLOR_CYAN, COLOR_RESET, COLOR_CYAN, COLOR_RESET);
    printf("  %sc%s, %scontinue%s     - Continue execution\n", COLOR_CYAN, COLOR_RESET, COLOR_CYAN, COLOR_RESET);
    printf("  %sn <count>%s      - Step N instructions\n", COLOR_CYAN, COLOR_RESET);
    printf("\n%sBreakpoints:%s\n", COLOR_BOLD, COLOR_RESET);
    printf("  %sb <addr>%s       - Set breakpoint at address (hex)\n", COLOR_CYAN, COLOR_RESET);
    printf("  %sd <addr>%s       - Delete breakpoint at address\n", COLOR_CYAN, COLOR_RESET);
    printf("  %sinfo b%s         - List all breakpoints\n", COLOR_CYAN, COLOR_RESET);
    printf("\n%sInspection:%s\n", COLOR_BOLD, COLOR_RESET);
    printf("  %sinfo reg%s       - Show registers\n", COLOR_CYAN, COLOR_RESET);
    printf("  %sinfo stack%s     - Show stack\n", COLOR_CYAN, COLOR_RESET);
    printf("  %sx <addr> [cnt]%s - Examine memory (default: 64 bytes)\n", COLOR_CYAN, COLOR_RESET);
    printf("  %sdisas [addr] [cnt]%s - Disassemble at address (default: PC, 10 instructions)\n", COLOR_CYAN, COLOR_RESET);
    printf("  %scontext%s        - Show full context (default view)\n", COLOR_CYAN, COLOR_RESET);
    printf("\n%sOther:%s\n", COLOR_BOLD, COLOR_RESET);
    printf("  %sh%s, %shelp%s, %s?%s      - Show this help\n", COLOR_CYAN, COLOR_RESET, COLOR_CYAN, COLOR_RESET, COLOR_CYAN, COLOR_RESET);
    printf("  %sq%s, %squit%s        - Quit debugger\n", COLOR_CYAN, COLOR_RESET, COLOR_CYAN, COLOR_RESET);
    printf("%s═════════════════════════════════════════════════════════════════════════=══════%s\n\n", 
           COLOR_BOLD_CYAN, COLOR_RESET);
}

// Command history
typedef struct {
    char history[MAX_HISTORY][MAX_CMD_LEN];
    int count;
    int current;
} CommandHistory;

void history_init(CommandHistory *hist) {
    hist->count = 0;
    hist->current = 0;
}

void history_add(CommandHistory *hist, const char *cmd) {
    if (cmd[0] == '\0') return;  // Don't add empty commands
    
    // Don't add if same as last command
    if (hist->count > 0 && strcmp(hist->history[hist->count - 1], cmd) == 0) {
        hist->current = hist->count;
        return;
    }
    
    if (hist->count < MAX_HISTORY) {
        strncpy(hist->history[hist->count], cmd, MAX_CMD_LEN - 1);
        hist->history[hist->count][MAX_CMD_LEN - 1] = '\0';
        hist->count++;
    } else {
        // Shift history and add to end
        memmove(hist->history[0], hist->history[1], (MAX_HISTORY - 1) * MAX_CMD_LEN);
        strncpy(hist->history[MAX_HISTORY - 1], cmd, MAX_CMD_LEN - 1);
        hist->history[MAX_HISTORY - 1][MAX_CMD_LEN - 1] = '\0';
    }
    hist->current = hist->count;
}

const char* history_prev(CommandHistory *hist) {
    if (hist->count == 0) return NULL;
    if (hist->current > 0) {
        hist->current--;
    }
    return hist->history[hist->current];
}

const char* history_next(CommandHistory *hist) {
    if (hist->count == 0) return NULL;
    if (hist->current < hist->count - 1) {
        hist->current++;
        return hist->history[hist->current];
    } else {
        hist->current = hist->count;
        return "";  // Return empty string when at the end
    }
}

// Read line with arrow key support
int read_line_with_history(char *buffer, int max_len, CommandHistory *hist) {
    struct termios old_term, new_term;
    int pos = 0;
    int c;
    
    // Get current terminal settings
    tcgetattr(STDIN_FILENO, &old_term);
    new_term = old_term;
    
    // Disable canonical mode and echo
    new_term.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &new_term);
    
    buffer[0] = '\0';
    
    while (1) {
        c = getchar();
        
        if (c == '\n') {
            // Enter key
            printf("\n");
            buffer[pos] = '\0';
            break;
        } else if (c == 127 || c == 8) {
            // Backspace
            if (pos > 0) {
                pos--;
                printf("\b \b");
                fflush(stdout);
            }
        } else if (c == 27) {
            // Escape sequence (arrow keys)
            if (getchar() == '[') {
                c = getchar();
                if (c == 'A') {
                    // Up arrow
                    const char *prev = history_prev(hist);
                    if (prev) {
                        // Clear current line
                        while (pos > 0) {
                            printf("\b \b");
                            pos--;
                        }
                        // Print previous command
                        printf("%s", prev);
                        fflush(stdout);
                        strncpy(buffer, prev, max_len - 1);
                        pos = strlen(buffer);
                    }
                } else if (c == 'B') {
                    // Down arrow
                    const char *next = history_next(hist);
                    if (next) {
                        // Clear current line
                        while (pos > 0) {
                            printf("\b \b");
                            pos--;
                        }
                        // Print next command
                        printf("%s", next);
                        fflush(stdout);
                        strncpy(buffer, next, max_len - 1);
                        pos = strlen(buffer);
                    }
                }
            }
        } else if (c >= 32 && c < 127 && pos < max_len - 1) {
            // Printable character
            buffer[pos++] = c;
            printf("%c", c);
            fflush(stdout);
        } else if (c == 4) {
            // Ctrl+D (EOF)
            tcsetattr(STDIN_FILENO, TCSANOW, &old_term);
            return 0;
        }
    }
    
    buffer[pos] = '\0';
    
    // Restore terminal settings
    tcsetattr(STDIN_FILENO, TCSANOW, &old_term);
    
    return 1;
}

// Main debugger loop
void debugger_loop(VMState *vm) {
    char cmd[MAX_CMD_LEN];
    char last_cmd[MAX_CMD_LEN] = "";
    CommandHistory history;
    int running = 1;
    
    history_init(&history);
    
    printf("\n%s╔════════════════════════════════════════════════════════════════════════════╗%s\n", 
           COLOR_BOLD_CYAN, COLOR_RESET);
    printf("%s║%s            %sFVM Debugger v3.14%s - Flag Verification Machine Debugger         %s║%s\n",
           COLOR_BOLD_CYAN, COLOR_RESET, COLOR_BOLD_YELLOW, COLOR_RESET, COLOR_BOLD_CYAN, COLOR_RESET);
    printf("%s╚════════════════════════════════════════════════════════════════════════════╝%s\n",
           COLOR_BOLD_CYAN, COLOR_RESET);
    printf("Type '%sh%s' or '%shelp%s' for available commands\n", 
           COLOR_CYAN, COLOR_RESET, COLOR_CYAN, COLOR_RESET);
    
    display_context(vm);
    
    while (running) {
        printf("\n%sfvm-dbg>%s ", COLOR_BOLD_GREEN, COLOR_RESET);
        fflush(stdout);
        
        if (!read_line_with_history(cmd, MAX_CMD_LEN, &history)) {
            break;
        }
        
        // If empty command, repeat last command
        if (cmd[0] == '\0') {
            if (last_cmd[0] != '\0') {
                strcpy(cmd, last_cmd);
            } else {
                continue;
            }
        } else {
            // Save this command as the last command and add to history
            strcpy(last_cmd, cmd);
            history_add(&history, cmd);
        }
        
        // Parse command
        char *token = strtok(cmd, " ");
        if (!token) continue;
        
        // Step
        if (strcmp(token, "s") == 0 || strcmp(token, "step") == 0) {
            if (vm->halt) {
                printf("%sProgram halted%s\n", COLOR_BOLD_YELLOW, COLOR_RESET);
            } else {
                vm_step(vm);
                display_context(vm);
                if (vm->halt) {
                    printf("\n%sProgram halted%s\n", COLOR_BOLD_YELLOW, COLOR_RESET);
                }
            }
        }
        // Run
        else if (strcmp(token, "r") == 0 || strcmp(token, "run") == 0 || strcmp(token, "c") == 0 || strcmp(token, "continue") == 0) {
            if (vm->halt) {
                printf("%sProgram already halted%s\n", COLOR_BOLD_YELLOW, COLOR_RESET);
            } else {
                int steps = 0;
                int max_steps = 100000;
                while (!vm->halt && steps < max_steps) {
                    vm_step(vm);
                    steps++;
                    if (at_breakpoint(vm)) {
                        printf("\n%sBreakpoint hit at 0x%02x%s\n", COLOR_BOLD_RED, vm->pc, COLOR_RESET);
                        break;
                    }
                }
                display_context(vm);
                if (vm->halt) {
                    printf("\n%sProgram halted after %d steps%s\n", COLOR_BOLD_YELLOW, steps, COLOR_RESET);
                } else if (steps >= max_steps) {
                    printf("\n%sMax steps reached (possible infinite loop)%s\n", COLOR_BOLD_RED, COLOR_RESET);
                }
            }
        }
        // Step N times
        else if (strcmp(token, "n") == 0) {
            char *arg = strtok(NULL, " ");
            int count = arg ? atoi(arg) : 1;
            for (int i = 0; i < count && !vm->halt; i++) {
                vm_step(vm);
            }
            display_context(vm);
            if (vm->halt) {
                printf("\n%sProgram halted%s\n", COLOR_BOLD_YELLOW, COLOR_RESET);
            }
        }
        // Set breakpoint
        else if (strcmp(token, "b") == 0 || strcmp(token, "break") == 0) {
            char *arg = strtok(NULL, " ");
            if (arg) {
                unsigned int addr;
                if (sscanf(arg, "%x", &addr) == 1 || sscanf(arg, "%d", &addr) == 1) {
                    add_breakpoint(vm, (uint8_t)addr);
                } else {
                    printf("%sInvalid address%s\n", COLOR_RED, COLOR_RESET);
                }
            } else {
                printf("%sUsage: b <address>%s\n", COLOR_YELLOW, COLOR_RESET);
            }
        }
        // Delete breakpoint
        else if (strcmp(token, "d") == 0 || strcmp(token, "delete") == 0) {
            char *arg = strtok(NULL, " ");
            if (arg) {
                unsigned int addr;
                if (sscanf(arg, "%x", &addr) == 1 || sscanf(arg, "%d", &addr) == 1) {
                    remove_breakpoint(vm, (uint8_t)addr);
                } else {
                    printf("%sInvalid address%s\n", COLOR_RED, COLOR_RESET);
                }
            } else {
                printf("%sUsage: d <address>%s\n", COLOR_YELLOW, COLOR_RESET);
            }
        }
        // Info commands
        else if (strcmp(token, "info") == 0) {
            char *arg = strtok(NULL, " ");
            if (!arg) {
                printf("%sUsage: info [reg|stack|b]%s\n", COLOR_YELLOW, COLOR_RESET);
            } else if (strcmp(arg, "reg") == 0 || strcmp(arg, "registers") == 0) {
                display_registers(vm);
            } else if (strcmp(arg, "stack") == 0) {
                display_stack(vm);
            } else if (strcmp(arg, "b") == 0 || strcmp(arg, "breakpoints") == 0) {
                list_breakpoints(vm);
            } else {
                printf("%sUnknown info command: %s%s\n", COLOR_RED, arg, COLOR_RESET);
            }
        }
        // Examine memory
        else if (strcmp(token, "x") == 0 || strcmp(token, "examine") == 0) {
            char *arg = strtok(NULL, " ");
            unsigned int addr = 0;
            int count = 64;
            
            if (arg) {
                sscanf(arg, "%x", &addr);
                arg = strtok(NULL, " ");
                if (arg) {
                    count = atoi(arg);
                }
            }
            examine_memory(vm, (uint16_t)addr, count);
        }
        // Disassemble
        else if (strcmp(token, "disas") == 0 || strcmp(token, "disassemble") == 0) {
            char *arg = strtok(NULL, " ");
            unsigned int addr = vm->pc;
            int count = 10;  // Default number of instructions
            
            if (arg) {
                sscanf(arg, "%x", &addr);
                // Check for optional count parameter
                arg = strtok(NULL, " ");
                if (arg) {
                    count = atoi(arg);
                    if (count <= 0) count = 10;
                }
            }
            
            printf("%sDisassembly at 0x%08x (%d instructions):%s\n", COLOR_BOLD, addr, count, COLOR_RESET);
            for (int i = 0; i < count && addr < vm->bytecode_size; i++) {
                printf("  ");
                disassemble_instruction(vm, addr, 0);
                uint8_t opcode = vm->memory[addr];
                addr += get_instruction_size(opcode);
            }
        }
        // Context
        else if (strcmp(token, "context") == 0 || strcmp(token, "ctx") == 0) {
            display_context(vm);
        }
        // Help
        else if (strcmp(token, "h") == 0 || strcmp(token, "help") == 0 || strcmp(token, "?") == 0) {
            print_help();
        }
        // Quit
        else if (strcmp(token, "q") == 0 || strcmp(token, "quit") == 0 || strcmp(token, "exit") == 0) {
            running = 0;
        }
        else {
            printf("%sUnknown command: '%s'. Type 'help' for available commands.%s\n", 
                   COLOR_RED, token, COLOR_RESET);
        }
    }
    
    printf("\n%sExiting debugger...%s\n", COLOR_BOLD_CYAN, COLOR_RESET);
}

void print_usage(const char *prog) {
    printf("Flag Validator Machine (FVM) Debugger\n");
    printf("Usage: %s <bytecode_file> <input>\n", prog);
    printf("  bytecode_file : Path to the bytecode file\n");
    printf("  input         : Input string (flag)\n");
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        print_usage(argv[0]);
        return 1;
    }
    
    const char *bytecode_file = argv[1];
    const char *flag_input = argv[2];
    
    VMState vm;
    vm_init(&vm, flag_input);
    
    // Load bytecode
    int bytes_loaded = load_bytecode(bytecode_file, vm.memory, MAX_MEMORY);
    if (bytes_loaded < 0) {
        return 1;
    }
    vm.bytecode_size = bytes_loaded;
    
    printf("%sLoaded %d bytes of bytecode from '%s'%s\n", 
           COLOR_BOLD_GREEN, bytes_loaded, bytecode_file, COLOR_RESET);
    
    // Start debugger
    debugger_loop(&vm);
    
    return 0;
}
