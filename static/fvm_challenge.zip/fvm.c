#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>

// Flag Validator Machine (FVM)

#define MAX_MEMORY 65535
#define MAX_STACK 64
#define FLAG_MAX_LEN 64

// Instruction opcodes
typedef enum {
    OP_NOP = 0x00,      // No operation
    OP_MOV = 0x01,      // MOV reg, value - Move value to register
    OP_LOAD = 0x02,     // LOAD reg, addr - Load from memory to register
    OP_STORE = 0x03,    // STORE addr, reg - Store register to memory
    OP_ADD = 0x04,      // ADD reg, value - Add value to register
    OP_SUB = 0x05,      // SUB reg, value - Subtract value from register
    OP_XOR = 0x06,      // XOR reg, value - XOR register with value
    OP_CMP = 0x07,      // CMP reg, value - Compare register with value (sets flags)
    OP_JMP = 0x08,      // JMP addr - Unconditional jump
    OP_JZ = 0x09,       // JZ addr - Jump if zero flag is set
    OP_JNZ = 0x0A,      // JNZ addr - Jump if zero flag is not set
    OP_PUSH = 0x0B,     // PUSH reg - Push register to stack
    OP_POP = 0x0C,      // POP reg - Pop from stack to register
    OP_PRINT = 0x0D,    // PRINT reg - Print register value
    OP_GETC = 0x0E,     // GETC reg, idx - Get character from input at index
    OP_GETCX = 0x0F,    // GETCX reg_dest, reg_idx - Get character from input at index from register
    OP_ZZZR = 0x10,     // ZZZR reg - Sleep for reg seconds (max 255 seconds)
    OP_ZZZ = 0x11,      // ZZZ seconds32 - Sleep for 4-byte immediate seconds value
    OP_RNG  = 0x12,     // RNG reg - Deterministic pseudo-random byte into register (PC-seeded)
    OP_BONK = 0x13,     // BONK - Rotate all registers: r0->r1, r1->r2, ..., r7->r0
    OP_ADDR = 0x14,     // ADDR reg_dest, reg_src - Add register to register
    OP_SUBR = 0x15,     // SUBR reg_dest, reg_src - Subtract register from register
    OP_XORR = 0x16,     // XORR reg_dest, reg_src - XOR register with register
    OP_CMPR = 0x17,     // CMPR reg1, reg2 - Compare two registers (sets zero flag)
    OP_WIPE = 0x18,     // WIPE - Zero all registers
    OP_HALT = 0xFF      // Halt execution
} Opcode;

// VM State
typedef struct {
    uint8_t regs[8];           // 8 general purpose registers (r0-r7)
    uint8_t memory[MAX_MEMORY]; // Memory space
    uint8_t stack[MAX_STACK];   // Stack
    uint8_t sp;                 // Stack pointer
    uint16_t pc;                // Program counter
    uint8_t zero_flag;          // Zero flag for comparisons
    uint8_t halt;               // Halt flag
    char input[FLAG_MAX_LEN];   // User input (flag)
    int input_len;              // Input length
    int trace;                  // Trace mode
    uint32_t rng_state;         // Internal state for RNG instruction
} VMState;

// Initialize VM
void vm_init(VMState *vm, const char *input) {
    memset(vm, 0, sizeof(VMState));
    strncpy(vm->input, input, FLAG_MAX_LEN - 1);
    vm->input_len = strlen(vm->input);
    vm->rng_state = 0xC0FEBABE;
}

// Load bytecode from text file
int load_bytecode(const char *filename, uint8_t *memory, size_t max_size) {
    FILE *f = fopen(filename, "r");
    if (!f) {
        fprintf(stderr, "Error: Cannot open bytecode file '%s'\n", filename);
        return -1;
    }
    
    char line[256];
    int code_idx = 0;
    int line_num = 0;
    
    while (fgets(line, sizeof(line), f) && code_idx < max_size) {
        line_num++;
        
        // Skip empty lines and comments
        if (line[0] == '\n' || line[0] == '#' || line[0] == ';') {
            continue;
        }
        
        // Parse hex bytes from the line
        char *ptr = line;
        while (*ptr && code_idx < max_size) {
            // Skip whitespace
            while (*ptr == ' ' || *ptr == '\t' || *ptr == '\n' || *ptr == '\r') {
                ptr++;
            }
            
            if (*ptr == '\0' || *ptr == '#' || *ptr == ';') {
                break; // End of line or comment
            }
            
            // Parse hex byte
            unsigned int byte;
            if (sscanf(ptr, "%2x", &byte) == 1) {
                memory[code_idx++] = (uint8_t)byte;
                ptr += 2;
            } else {
                fprintf(stderr, "Warning: Invalid hex on line %d\n", line_num);
                break;
            }
        }
    }
    
    fclose(f);
    
    if (code_idx == 0) {
        fprintf(stderr, "Error: No valid bytecode found\n");
        return -1;
    }
    
    return code_idx;
}

// Execute one instruction
void vm_step(VMState *vm) {
    if (vm->pc >= MAX_MEMORY) {
        fprintf(stderr, "Error: PC out of bounds\n");
        vm->halt = 1;
        return;
    }
    
    uint8_t opcode = vm->memory[vm->pc];
    uint8_t arg1 = vm->memory[vm->pc + 1];
    uint8_t arg2 = vm->memory[vm->pc + 2];
    uint8_t arg3 = vm->memory[vm->pc + 3];
    uint8_t arg4 = vm->memory[vm->pc + 4];
    
    if (vm->trace) {
        printf("[TRACE] PC=%03d OP=0x%02X ARG1=0x%02X ARG2=0x%02X\n", 
               vm->pc, opcode, arg1, arg2);
    }
    
    switch (opcode) {
        case OP_NOP:
            vm->pc += 1;
            break;
            
        case OP_MOV:
            if (arg1 < 8) {
                vm->regs[arg1] = arg2;
            }
            vm->pc += 3;
            break;
            
        case OP_LOAD: {
            uint32_t base_addr = (arg2 << 24) | (arg3 << 16) | (arg4 << 8) | vm->memory[vm->pc + 5];
            uint8_t reg_offset = vm->memory[vm->pc + 6];
            if (arg1 < 8 && reg_offset < 8) {
                uint32_t addr = base_addr + vm->regs[reg_offset];
                if (addr < MAX_MEMORY) {
                    vm->regs[arg1] = vm->memory[addr];
                }
            }
            vm->pc += 7;
            break;
        }
            
        case OP_STORE: {
            uint32_t base_addr = (arg1 << 24) | (arg2 << 16) | (arg3 << 8) | arg4;
            uint8_t reg_offset = vm->memory[vm->pc + 5];
            uint8_t reg_src = vm->memory[vm->pc + 6];
            if (reg_offset < 8 && reg_src < 8) {
                uint32_t addr = base_addr + vm->regs[reg_offset];
                if (addr < MAX_MEMORY) {
                    vm->memory[addr] = vm->regs[reg_src];
                }
            }
            vm->pc += 7;
            break;
        }
            
        case OP_ADD:
            if (arg1 < 8) {
                vm->regs[arg1] += arg2;
            }
            vm->pc += 3;
            break;
            
        case OP_SUB:
            if (arg1 < 8) {
                vm->regs[arg1] -= arg2;
            }
            vm->pc += 3;
            break;
            
        case OP_XOR:
            if (arg1 < 8) {
                vm->regs[arg1] ^= arg2;
            }
            vm->pc += 3;
            break;
            
        case OP_CMP:
            if (arg1 < 8) {
                vm->zero_flag = (vm->regs[arg1] == arg2) ? 1 : 0;
            }
            vm->pc += 3;
            break;
            
        case OP_JMP: {
            uint32_t addr = (arg1 << 24) | (arg2 << 16) | (arg3 << 8) | arg4;
            vm->pc = addr;
            break;
        }
            
        case OP_JZ: {
            uint32_t addr = (arg1 << 24) | (arg2 << 16) | (arg3 << 8) | arg4;
            if (vm->zero_flag) {
                vm->pc = addr;
            } else {
                vm->pc += 5;
            }
            break;
        }
            
        case OP_JNZ: {
            uint32_t addr = (arg1 << 24) | (arg2 << 16) | (arg3 << 8) | arg4;
            if (!vm->zero_flag) {
                vm->pc = addr;
            } else {
                vm->pc += 5;
            }
            break;
        }
            
        case OP_PUSH:
            if (arg1 < 8 && vm->sp < MAX_STACK) {
                vm->stack[vm->sp++] = vm->regs[arg1];
            }
            vm->pc += 2;
            break;
            
        case OP_POP:
            if (arg1 < 8 && vm->sp > 0) {
                vm->regs[arg1] = vm->stack[--vm->sp];
            }
            vm->pc += 2;
            break;
            
        case OP_PRINT:
            if (arg1 < 8) {
                printf("%c", vm->regs[arg1]);
            }
            vm->pc += 2;
            break;
            
        case OP_GETC:
            if (arg1 < 8) {
                if (arg2 < vm->input_len) {
                    vm->regs[arg1] = vm->input[arg2];
                } else {
                    vm->regs[arg1] = 0;
                }
            }
            vm->pc += 3;
            break;
            
        case OP_GETCX:
            if (arg1 < 8 && arg2 < 8) {
                uint8_t idx = vm->regs[arg2];
                if (idx < vm->input_len) {
                    vm->regs[arg1] = vm->input[idx];
                } else {
                    vm->regs[arg1] = 0;
                }
            }
            vm->pc += 3;
            break;
            
        case OP_ZZZR:
            if (arg1 < 8) {
                unsigned int sleep_seconds = vm->regs[arg1];
                if (vm->trace) {
                    printf("[TRACE] ZZZR: Sleeping for %u seconds... 💤\n", sleep_seconds);
                }
                sleep(sleep_seconds);
            }
            vm->pc += 2;
            break;
            
        case OP_ZZZ: {
            uint32_t sleep_seconds = (arg1 << 24) | (arg2 << 16) | (arg3 << 8) | arg4;
            if (vm->trace) {
                printf("[TRACE] ZZZ: Sleeping for %u seconds... 💤💤💤\n", sleep_seconds);
            }
            sleep(sleep_seconds);
            vm->pc += 5;
            break;
        }
            
        case OP_ADDR:
            if (arg1 < 8 && arg2 < 8) {
                vm->regs[arg1] += vm->regs[arg2];
            }
            vm->pc += 3;
            break;
            
        case OP_SUBR:
            if (arg1 < 8 && arg2 < 8) {
                vm->regs[arg1] -= vm->regs[arg2];
            }
            vm->pc += 3;
            break;
            
        case OP_XORR:
            if (arg1 < 8 && arg2 < 8) {
                vm->regs[arg1] ^= vm->regs[arg2];
            }
            vm->pc += 3;
            break;
            
        case OP_CMPR:
            if (arg1 < 8 && arg2 < 8) {
                vm->zero_flag = (vm->regs[arg1] == vm->regs[arg2]) ? 1 : 0;
            }
            vm->pc += 3;
            break;
            
        case OP_RNG:
            if (arg1 < 8) {
                vm->rng_state ^= (uint32_t)vm->pc;
                vm->rng_state = vm->rng_state * 1664525u + 1013904223u;
                vm->regs[arg1] = (uint8_t)((vm->rng_state >> 16) & 0xFF);
            }
            vm->pc += 2;
            break;

        case OP_BONK: {
            uint8_t tmp = vm->regs[7];
            vm->regs[7] = vm->regs[6];
            vm->regs[6] = vm->regs[5];
            vm->regs[5] = vm->regs[4];
            vm->regs[4] = vm->regs[3];
            vm->regs[3] = vm->regs[2];
            vm->regs[2] = vm->regs[1];
            vm->regs[1] = vm->regs[0];
            vm->regs[0] = tmp;
            vm->pc += 1;
            break;
        }

        case OP_WIPE:
            memset(vm->regs, 0, sizeof(vm->regs));
            vm->pc += 1;
            break;
            
        case OP_HALT:
            vm->halt = 1;
            break;
            
        default:
            fprintf(stderr, "Error: Unknown opcode 0x%02X at PC=%d\n", opcode, vm->pc);
            vm->halt = 1;
            break;
    }
}

// Run the VM
void vm_run(VMState *vm, int max_steps) {
    int steps = 0;
    
    while (!vm->halt && steps < max_steps) {
        vm_step(vm);
        steps++;
        
        if (vm->trace && steps % 10 == 0) {
            printf("[TRACE] Registers: ");
            for (int i = 0; i < 8; i++) {
                printf("r%d=0x%02X ", i, vm->regs[i]);
            }
            printf("\n");
        }
    }
    
    if (steps >= max_steps) {
        fprintf(stderr, "\nError: Maximum steps exceeded (infinite loop?)\n");
    }
}

void print_usage(const char *prog) {
    printf("Flag Validator Machine (FVM)\n");
    printf("Usage: %s [-t] <bytecode_file> <input>\n", prog);
    printf("  -t : Enable trace mode (show execution)\n");
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        print_usage(argv[0]);
        return 1;
    }
    
    int trace = 0;
    int arg_offset = 1;
    
    // Check if first argument is -t
    if (strcmp(argv[1], "-t") == 0) {
        trace = 1;
        arg_offset = 2;
        
        if (argc < 4) {
            print_usage(argv[0]);
            return 1;
        }
    }
    
    const char *bytecode_file = argv[arg_offset];
    const char *flag_input = argv[arg_offset + 1];
    
    VMState vm;
    vm_init(&vm, flag_input);
    vm.trace = trace;
    
    // Load bytecode
    int bytes_loaded = load_bytecode(bytecode_file, vm.memory, MAX_MEMORY);
    if (bytes_loaded < 0) {
        return 1;
    }
    
    if (trace) {
        printf("[TRACE] Loaded %d bytes of bytecode\n", bytes_loaded);
        printf("[TRACE] Input: '%s' (length: %d)\n", vm.input, vm.input_len);
    }
    
    // Run VM
    vm_run(&vm, 10000);  // Max 10000 steps to prevent infinite loops
    
    printf("\n");
    
    return 0;
}
