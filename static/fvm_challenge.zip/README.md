# Flag Validator Machine (FVM)  

## Usage

Default usage:
```
./fvm [-t] <bytecode_file> <input_text>  
  -t : Enable trace mode (show execution, optional)  
  <bytecode_file> : The bytecode file to be executed  
  <input_text> : The input text to be processed by the VM  
```

Example:
```
./fvm bytecode_1_Simple.fvm FLAG{example_flag}
```

Using the FVM debugger:
```
./fvm_debug <bytecode_file> <input_text>  
  <bytecode_file> : The bytecode file to be executed  
  <input_text> : The input text to be processed by the VM  
```
Use the help command for more information.

## Build

```
make
```
